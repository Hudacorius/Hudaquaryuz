<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    .cool-detail-wrapper {
        max-width: 600px;
        margin: 40px auto;
        background: linear-gradient(180deg, #f0f9ff 0%, #ffffff 35%);
        border: 1px solid #bae6fd;
        border-radius: 16px;
        box-shadow: 0 10px 25px -5px rgba(14, 116, 144, 0.12);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #0f172a;
        overflow: hidden;
    }

    .cool-header {
        background: linear-gradient(135deg, #0284c7 0%, #0f172a 100%);
        padding: 24px 32px;
        color: #ffffff;
    }

    .cool-header h1 {
        margin: 0;
        font-size: 22px;
        font-weight: 700;
        letter-spacing: 0.3px;
    }

    .cool-header p {
        margin: 4px 0 0 0;
        font-size: 13px;
        color: #bae6fd;
    }

    .cool-body {
        padding: 28px 32px;
    }

    .cool-alert-success {
        background-color: #ecfeff;
        color: #155e75;
        border: 1px solid #a5f3fc;
        border-left: 4px solid #06b6d4;
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 22px;
        font-size: 14px;
        font-weight: 500;
    }

    .detail-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .detail-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 18px;
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        transition: all 0.2s ease;
    }

    .detail-item:hover {
        background-color: #f0f9ff;
        border-color: #7dd3fc;
    }

    .detail-label {
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #475569;
    }

    .detail-value {
        font-size: 15px;
        font-weight: 600;
        color: #0c4a6e;
    }

    .detail-badge {
        background-color: #e0f2fe;
        color: #0369a1;
        padding: 4px 12px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
    }

    .cool-footer {
        margin-top: 28px;
        padding-top: 20px;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: flex-start;
    }

    .btn-cool-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background-color: #e0f2fe;
        color: #0369a1;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        border-radius: 8px;
        border: 1px solid #bae6fd;
        transition: all 0.2s ease;
    }

    .btn-cool-back:hover {
        background-color: #0284c7;
        color: #ffffff;
        border-color: #0284c7;
    }

    @media (max-width: 600px) {
        .cool-detail-wrapper {
            margin: 16px;
        }
        .cool-header, .cool-body {
            padding: 20px;
        }
        .detail-item {
            flex-direction: column;
            align-items: flex-start;
            gap: 4px;
        }
    }
</style>

<div class="cool-detail-wrapper">
    <div class="cool-header">
        <h1>Detail Siswa</h1>
        <p>Informasi profil akademik siswa terdaftar</p>
    </div>

    <div class="cool-body">
        <?php if (!empty($success)): ?>
            <div class="cool-alert-success">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <div class="detail-list">
            <div class="detail-item">
                <span class="detail-label">NIS</span>
                <span class="detail-badge"><?= htmlspecialchars($student['nis']) ?></span>
            </div>

            <div class="detail-item">
                <span class="detail-label">Nama Lengkap</span>
                <span class="detail-value"><?= htmlspecialchars($student['name']) ?></span>
            </div>

            <div class="detail-item">
                <span class="detail-label">Kelas</span>
                <span class="detail-value"><?= htmlspecialchars($student['class_name']) ?></span>
            </div>

            <div class="detail-item">
                <span class="detail-label">Jurusan</span>
                <span class="detail-value"><?= htmlspecialchars($student['major']) ?></span>
            </div>
        </div>

        <div class="cool-footer">
            <a href="index.php" class="btn-cool-back">
                ← Kembali
            </a>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
