<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    .student-form-wrapper {
        max-width: 650px;
        margin: 40px auto;
        padding: 32px;
        background-color: #ffffff;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #1f2937;
    }

    .form-header {
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 1px solid #e5e7eb;
    }

    .form-header h1 {
        margin: 0 0 6px 0;
        font-size: 24px;
        font-weight: 700;
        color: #111827;
    }

    .form-header p {
        margin: 0;
        font-size: 14px;
        color: #6b7280;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 18px;
    }

    .form-group.full-width {
        grid-column: 1 / -1;
    }

    .form-label {
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 6px;
        color: #374151;
    }

    .form-label span.required {
        color: #ef4444;
    }

    .form-control {
        padding: 10px 14px;
        font-size: 15px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        background-color: #f9fafb;
        color: #111827;
        transition: all 0.2s ease;
    }

    .form-control:focus {
        outline: none;
        border-color: #2563eb;
        background-color: #ffffff;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
    }

    .radio-group {
        display: flex;
        gap: 14px;
        margin-top: 4px;
    }

    .radio-card {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 14px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        background-color: #f9fafb;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.2s ease;
    }

    .radio-card:hover {
        border-color: #93c5fd;
        background-color: #eff6ff;
    }

    .radio-card input[type="radio"] {
        accent-color: #2563eb;
        width: 16px;
        height: 16px;
        margin: 0;
    }

    .form-actions {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 12px;
        margin-top: 28px;
        padding-top: 20px;
        border-top: 1px solid #e5e7eb;
    }

    .btn {
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 600;
        border-radius: 8px;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .btn-primary {
        background-color: #2563eb;
        color: #ffffff;
    }

    .btn-primary:hover {
        background-color: #1d4ed8;
    }

    .btn-secondary {
        background-color: #f3f4f6;
        color: #4b5563;
    }

    .btn-secondary:hover {
        background-color: #e5e7eb;
        color: #1f2937;
    }

    /* Responsif untuk layar HP */
    @media (max-width: 600px) {
        .student-form-wrapper {
            margin: 16px;
            padding: 20px;
        }
        .form-grid {
            grid-template-columns: 1fr;
            gap: 0;
        }
        .form-actions {
            flex-direction: column-reverse;
        }
        .btn {
            width: 100%;
        }
    }
</style>

<div class="student-form-wrapper">
    <div class="form-header">
        <h1>Tambah Siswa</h1>
        <p>Lengkapi formulir di bawah ini untuk menambahkan data siswa baru.</p>
    </div>

    <form action="create.php" method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label class="form-label" for="nis">NIS <span class="required">*</span></label>
                <input
                    type="text"
                    id="nis"
                    name="nis"
                    class="form-control"
                    placeholder="Contoh: 2026001"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="name">Nama Lengkap <span class="required">*</span></label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    class="form-control"
                    placeholder="Masukkan nama lengkap"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="birth_place">Tempat Lahir</label>
                <input
                    type="text"
                    id="birth_place"
                    name="birth_place"
                    class="form-control"
                    placeholder="Kota kelahiran"
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="birth_date">Tanggal Lahir</label>
                <input
                    type="date"
                    id="birth_date"
                    name="birth_date"
                    class="form-control"
                >
            </div>

            <div class="form-group full-width">
                <label class="form-label">Jenis Kelamin <span class="required">*</span></label>
                <div class="radio-group">
                    <label class="radio-card">
                        <input
                            type="radio"
                            name="gender"
                            value="L"
                            required
                        >
                        Laki-laki
                    </label>

                    <label class="radio-card">
                        <input
                            type="radio"
                            name="gender"
                            value="P"
                        >
                        Perempuan
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="class_name">Kelas <span class="required">*</span></label>
                <input
                    type="text"
                    id="class_name"
                    name="class_name"
                    class="form-control"
                    placeholder="Contoh: X, XI, XII"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="major">Jurusan <span class="required">*</span></label>
                <input
                    type="text"
                    id="major"
                    name="major"
                    class="form-control"
                    placeholder="Contoh: RPL, TKJ, IPA"
                    required
                >
            </div>
        </div>

        <div class="form-actions">
            <a href="index.php" class="btn btn-secondary">
                Batal
            </a>
            <button type="submit" class="btn btn-primary">
                Simpan Data
            </button>
        </div>
    </form>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
