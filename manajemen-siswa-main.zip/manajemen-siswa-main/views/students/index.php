<?php require 'views/layouts/header.php'; ?>

<style>
    /* === AQUARIUS VIBE CONTENT THEME === */
    .aquarius-container {
        max-width: 1140px;
        margin: 0 auto;
        padding: 0 16px;
        font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
    }

    /* Header Judul Halaman */
    .page-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 24px;
    }

    .page-title {
        font-size: 28px;
        font-weight: 800;
        margin: 0;
        letter-spacing: -0.5px;
        background: linear-gradient(135deg, #2563eb 0%, #08dffc 50%, #e00fb3 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Notifikasi Sukses */
    .alert-aquarius {
        background: linear-gradient(135deg, rgba(8, 223, 252, 0.12), rgba(37, 99, 235, 0.08));
        color: #0369a1;
        border-left: 4px solid #08dffc;
        border-top: 1px solid rgba(8, 223, 252, 0.35);
        border-right: 1px solid rgba(8, 223, 252, 0.35);
        border-bottom: 1px solid rgba(8, 223, 252, 0.35);
        padding: 14px 18px;
        border-radius: 12px;
        margin-bottom: 20px;
        font-size: 14px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(8, 223, 252, 0.12);
    }

    /* Pembungkus Tabel Modern */
    .table-card {
        background: rgba(255, 255, 255, 0.96);
        backdrop-filter: blur(12px);
        border-radius: 18px;
        box-shadow: 0 15px 35px rgba(37, 99, 235, 0.12), 0 4px 12px rgba(8, 223, 252, 0.08);
        border: 1px solid rgba(8, 223, 252, 0.3);
        overflow-x: auto; /* Agar bisa digeser di layar HP */
    }

    .aquarius-table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
        font-size: 14px;
    }

    /* Header Tabel Gradasi Aquarius */
    .aquarius-table thead {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 60%, #08dffc 100%);
        color: #ffffff;
    }

    .aquarius-table th {
        padding: 16px 18px;
        font-weight: 700;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        white-space: nowrap;
    }

    /* Isi Baris Tabel */
    .aquarius-table tbody tr {
        border-bottom: 1px solid #e0f2fe;
        transition: all 0.2s ease;
    }

    .aquarius-table tbody tr:last-child {
        border-bottom: none;
    }

    .aquarius-table tbody tr:hover {
        background: rgba(8, 223, 252, 0.08);
    }

    .aquarius-table td {
        padding: 14px 18px;
        color: #1e293b;
        vertical-align: middle;
    }

    /* Badge Nomor & NIS */
    .badge-nis {
        background: #eff6ff;
        color: #2563eb;
        padding: 4px 10px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 13px;
        border: 1px solid #bfdbfe;
    }

    .student-name {
        font-weight: 600;
        color: #0f172a;
    }

    /* Tombol Aksi */
    .action-group {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: nowrap;
    }

    .btn-action {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
    }

    .btn-detail {
        background: rgba(8, 223, 252, 0.15);
        color: #0284c7;
        border: 1px solid rgba(8, 223, 252, 0.4);
    }
    .btn-detail:hover {
        background: #08dffc;
        color: #0f172a;
        transform: translateY(-1px);
    }

    .btn-edit {
        background: rgba(37, 99, 235, 0.12);
        color: #2563eb;
        border: 1px solid rgba(37, 99, 235, 0.3);
    }
    .btn-edit:hover {
        background: #2563eb;
        color: #ffffff;
        transform: translateY(-1px);
    }

    .btn-delete {
        background: rgba(224, 15, 179, 0.1);
        color: #e00fb3;
        border: 1px solid rgba(224, 15, 179, 0.3);
    }
    .btn-delete:hover {
        background: #e00fb3;
        color: #ffffff;
        transform: translateY(-1px);
        box-shadow: 0 4px 10px rgba(224, 15, 179, 0.3);
    }
</style>

<div class="aquarius-container">
    <div class="page-header">
        <h1 class="page-title">Daftar Siswa</h1>
    </div>

    <?php if (!empty($success)): ?>
        <div class="alert-aquarius">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <div class="table-card">
        <table class="aquarius-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($students as $index => $student): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><span class="badge-nis"><?= htmlspecialchars($student['nis']) ?></span></td>
                        <td class="student-name"><?= htmlspecialchars($student['name']) ?></td>
                        <td><?= htmlspecialchars($student['gender']) ?></td>
                        <td><?= htmlspecialchars($student['class_name']) ?></td>
                        <td><?= htmlspecialchars($student['major']) ?></td>
                        <td>
                            <div class="action-group">
                                <a href="student.php?id=<?= $student['id'] ?>" class="btn-action btn-detail">
                                    Detail
                                </a>
                                <a href="edit.php?id=<?= $student['id'] ?>" class="btn-action btn-edit">
                                    Edit
                                </a>
                                <a href="delete.php?id=<?= $student['id'] ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">
                                    Hapus
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require 'views/layouts/footer.php'; ?>
