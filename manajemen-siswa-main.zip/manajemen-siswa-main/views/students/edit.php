<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
    /* === WINTER FROST THEME === */
    .winter-wrapper {
        max-width: 620px;
        margin: 20px auto 40px;
        padding: 0 16px;
        font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
    }

    /* Kartu Kaca Es (Frosted Ice Card) */
    .frost-card {
        background: linear-gradient(145deg, rgba(255, 255, 255, 0.96), rgba(240, 249, 255, 0.94));
        backdrop-filter: blur(14px);
        border-radius: 22px;
        padding: 36px 32px;
        border: 1.5px solid #bae6fd;
        box-shadow: 
            0 20px 40px rgba(2, 132, 199, 0.12),
            0 4px 16px rgba(186, 230, 253, 0.4),
            inset 0 0 20px rgba(255, 255, 255, 0.8);
    }

    /* Header Form */
    .frost-header {
        text-align: center;
        margin-bottom: 28px;
        padding-bottom: 18px;
        border-bottom: 1px dashed #bae6fd;
    }

    .frost-header h1 {
        margin: 0 0 6px;
        font-size: 26px;
        font-weight: 800;
        letter-spacing: -0.4px;
        background: linear-gradient(135deg, #0369a1 0%, #0284c7 50%, #38bdf8 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    .frost-header p {
        margin: 0;
        font-size: 14px;
        color: #64748b;
    }

    /* Tata Letak Form */
    .form-group {
        margin-bottom: 20px;
    }

    .form-label {
        display: block;
        font-size: 13px;
        font-weight: 700;
        color: #0c4a6e;
        margin-bottom: 7px;
        letter-spacing: 0.2px;
    }

    /* Input Teks Sejuk */
    .frost-input {
        width: 100%;
        box-sizing: border-box;
        padding: 12px 15px;
        background: #f8fafc;
        border: 1.5px solid #cbd5e1;
        border-radius: 12px;
        font-size: 14px;
        color: #0f172a;
        transition: all 0.25s ease;
    }

    .frost-input:hover {
        border-color: #7dd3fc;
        background: #ffffff;
    }

    .frost-input:focus {
        outline: none;
        background: #ffffff;
        border-color: #0284c7;
        box-shadow: 0 0 0 4px rgba(56, 189, 248, 0.2);
    }

    /* Pilihan Radio Button Modern */
    .radio-group {
        display: flex;
        gap: 14px;
        flex-wrap: wrap;
    }

    .radio-card {
        flex: 1;
        min-width: 140px;
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 11px 16px;
        background: #f0f9ff;
        border: 1.5px solid #bae6fd;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        color: #0369a1;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .radio-card:hover {
        background: #e0f2fe;
        border-color: #38bdf8;
    }

    .radio-card input[type="radio"] {
        accent-color: #0284c7;
        width: 16px;
        height: 16px;
        margin: 0;
        cursor: pointer;
    }

    /* Tombol Aksi */
    .form-actions {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-top: 28px;
        padding-top: 18px;
        border-top: 1px solid #e0f2fe;
    }

    .btn-winter-submit {
        flex: 2;
        padding: 13px 20px;
        border: none;
        border-radius: 12px;
        background: linear-gradient(135deg, #0284c7 0%, #38bdf8 100%);
        color: #ffffff;
        font-size: 15px;
        font-weight: 700;
        cursor: pointer;
        box-shadow: 0 6px 18px rgba(2, 132, 199, 0.28);
        transition: all 0.25s ease;
    }

    .btn-winter-submit:hover {
        background: linear-gradient(135deg, #0369a1 0%, #0284c7 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 24px rgba(2, 132, 199, 0.38);
    }

    .btn-winter-cancel {
        flex: 1;
        text-align: center;
        padding: 12px 18px;
        border-radius: 12px;
        background: #f1f5f9;
        color: #475569;
        border: 1.5px solid #cbd5e1;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
    }

    .btn-winter-cancel:hover {
        background: #e2e8f0;
        color: #0f172a;
        border-color: #94a3b8;
    }
</style>

<div class="winter-wrapper">
    <div class="frost-card">
        <div class="frost-header">
            <h1>Edit Data Siswa</h1>
            <p>Silakan perbarui informasi data siswa pada kolom di bawah ini.</p>
        </div>

        <form action="update.php?id=<?= $student['id'] ?>" method="POST">
            
            <div class="form-group">
                <label class="form-label" for="nis">NIS</label>
                <input
                    type="text"
                    id="nis"
                    name="nis"
                    class="frost-input"
                    value="<?= htmlspecialchars($student['nis']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="name">Nama Lengkap</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    class="frost-input"
                    value="<?= htmlspecialchars($student['name']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label">Jenis Kelamin</label>
                <div class="radio-group">
                    <label class="radio-card">
                        <input
                            type="radio"
                            name="gender"
                            value="L"
                            <?= $student['gender'] === 'L' ? 'checked' : '' ?>
                            required
                        >
                        Laki-laki
                    </label>

                    <label class="radio-card">
                        <input
                            type="radio"
                            name="gender"
                            value="P"
                            <?= $student['gender'] === 'P' ? 'checked' : '' ?>
                        >
                        Perempuan
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="class_name">Kelas</label>
                <input
                    type="text"
                    id="class_name"
                    name="class_name"
                    class="frost-input"
                    value="<?= htmlspecialchars($student['class_name']) ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label class="form-label" for="major">Jurusan</label>
                <input
                    type="text"
                    id="major"
                    name="major"
                    class="frost-input"
                    value="<?= htmlspecialchars($student['major']) ?>"
                    required
                >
            </div>

            <div class="form-actions">
                <a href="index.php" class="btn-winter-cancel">Batal</a>
                <button type="submit" class="btn-winter-submit">Simpan Perubahan</button>
            </div>

        </form>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
